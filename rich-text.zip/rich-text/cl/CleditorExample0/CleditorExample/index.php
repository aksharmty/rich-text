<?php
echo "sffff".$_GET["a"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Cleditor Example</title>
    <link href="Content/cleditor/jquery.cleditor.css" rel="stylesheet" type="text/css" />
    <!--link href="Content/Site.css" rel="stylesheet" type="text/css" / -->

    <script src="Scripts/jquery-1.6.3.js" type="text/javascript"></script>
    <script src="Scripts/jquery.cleditor.js" type="text/javascript"></script>

<script type="text/javascript">

    $(document).ready(function () {
        var options = {
            width: 400,
            height: 200,
            controls: "bold italic underline strikethrough subscript superscript | font size " +
                    "style | color highlight removeformat | bullets numbering | outdent " +
                    "indent | alignleft center alignright justify | undo redo | " +
                     "rule link unlink | cut copy paste pastetext | print source"
                     //"rule link image unlink | cut copy paste pastetext | print source"
        };

        var editor = $("#editor").cleditor(options)[0];

        $("#btnClear").click(function (e) {
            e.preventDefault();
            editor.focus();
            editor.clear();
        });

        $("#btnAddImage").click(function () {
            editor.execCommand("insertimage", "http://images.free-extras.com/pics/s/smile-1620.JPG", null, null)
            editor.focus();
        });

        $("#btnGetHtml").click(function () {
            alert($("#editor").val());
        });

    });
</script>
</head>

<body>
<div style="width: 400px">
    <div>
        <form action="" method="get">
        <textarea name ="a" id="editor" rows="0" cols="0"></textarea>
        <input type="submit" value="submit">
    </div>
    <div class="normaldiv" style="float: right">
        <a href="#" class="siteButton" id="btnClear">Clear</a>
        <a href="#" class="siteButton" id="btnAddImage">Add an image</a>
        <a href="#" class="siteButton" id="btnGetHtml">Get html</a>
         <a href="#" class="siteButton" id="btnGetHtml">Submit</a>
    </div></form>
</div>
</body>
</html>