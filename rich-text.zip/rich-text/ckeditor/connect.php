<?php
$connection = mysqli_connect('localhost', 'adquash2_sunita', 'lCsjN@PfQ^Y9', 'adquash2_classified');
if ($connection->connect_error) {
  die("Connection failed: " . $connection->connect_error);
}
?>