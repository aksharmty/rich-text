<?php

    $content = $_POST['content'];
    
echo " get " . $content;
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>CKEditor 5 ClassicEditor build</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="styles.css">
	</head>
	<body data-editor="ClassicEditor" data-collaboration="false" data-revision-history="false">
	
		<div class="message">
			<div class="centered">
				<h2>CKEditor 5 online builder demo - ClassicEditor build</h2>
			</div>
		</div><form action="" method="post">
	<textarea id="content" name="content" class="editor"></textarea>
	<input type="submit" name="submit" value="submit">
		
		<footer>
			<p><a href="https://ckeditor.com/ckeditor-5/" target="_blank" rel="noopener">CKEditor 5</a>
				– Rich text editor of tomorrow, available today
			</p>
			<p>Copyright © 2003-2024,
				<a href="https://cksource.com/" target="_blank" rel="noopener">CKSource</a>
				Holding sp. z o.o. All rights reserved.
			</p>
		</footer>
		<script src="build/ckeditor.js"></script>
		<script src="script.js"></script>
		<!--script> CKEDITOR.replace('editor')            .then(editor => {
          console.log(editor);
        })
        .catch( error => {
            console.error( error );
        }); -->
</script>
	</body>
</html>